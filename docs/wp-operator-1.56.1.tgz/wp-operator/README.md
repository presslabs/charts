# WordPress Operator

This is the helm chart for [wordpress-operator](https://github.com/presslabs/wp-operator).

## TL;DR
```sh
helm repo add presslabs https://presslabs.github.io/charts
helm install wp-operator presslabs/wp-operator
```

## Configuration
The following table contains the configuration parameters for wordpress-operator and default values.

| Parameter                       | Description                                                                                   | Default value                                           |
| ---                             | ---                                                                                           | ---                                                     |
| `replicas`                      | Replicas for controller                                                                       | `1`                                                     |
| `image.repository`              | Controller image repository                                                                   | `gcr.io/pl-infra/stack/wp-operator:latest`				|
| `image.pullPolicy`              | Controller image pull policy                                                                  | `IfNotPresent`                                          |
| `image.tag       `              | Controller image tag                                                                          | `latest`                                                |
| `imagePullSecrets`              | Controller image pull secret                                                                  |                                                         |
| `resources`                     | Controller container resources limits and requests                                            | `{}`                                                    |
| `nodeSelector`                  | Controller pod nodeSelector                                                                   | `{}`                                                    |
| `tolerations`                   | Controller pod tolerations                                                                    | `{}`                                                    |
| `affinity`                      | Controller pod node affinity                                                                  | `{}`                                                    |
| `extraArgs`                     | Args that are passed to controller, check controller command line flags                       | `[]`                                                    |
| `extraEnv`                      | Extra environment vars that are passed to controller, check controller command line flags     | `{}`                                                    |
| `rbac.create`                   | Whether or not to create rbac service account, role and roleBinding                           | `true`                                                  |
| `serviceAccount.create`         | Specifies whether a service account should be created                                         | `true`                                                  |
| `serviceAccount.annotations`    | Annotations to add to the service account                                                     | `{}`                                                    |
| `serviceAccount.name`           | The name of the service account to use. If not set and create is true, a name is generated using the fullname template. | `empty`                       |
